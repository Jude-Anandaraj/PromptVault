# PromptVault

A MERN-stack AI prompt sharing platform for COMP229.

## Features
- Register and log in with JWT authentication
- Browse and search public prompts
- Filter prompts by category
- View prompt details and copy prompt text
- Create, edit, and delete your own prompts
- Responsive React interface
- Express REST API with MongoDB/Mongoose
- Password hashing with bcrypt and protected routes

## Requirements
- Node.js 20+
- MongoDB local instance or MongoDB Atlas connection string

## 1. Configure the backend

```bash
cd server
cp .env.example .env
```

Set `MONGODB_URI` and a long random `JWT_SECRET` in `server/.env`.

Install and run:

```bash
npm install
npm run dev
```

The API runs at `http://localhost:5000`.

## 2. Configure the frontend

Open a second terminal:

```bash
cd client
cp .env.example .env
npm install
npm run dev
```

Open the Vite URL shown in the terminal (normally `http://localhost:5173`).

## API routes

| Method | Route | Access | Purpose |
|---|---|---|---|
| POST | `/api/auth/register` | Public | Create an account |
| POST | `/api/auth/login` | Public | Log in |
| GET | `/api/auth/me` | Private | Get current user |
| GET | `/api/prompts` | Public | Browse/search prompts |
| GET | `/api/categories` | Public | List supported prompt categories |
| GET | `/api/categories` | Public | List prompt categories |
| GET | `/api/prompts/:id` | Public | View one prompt |
| POST | `/api/prompts` | Private | Create a prompt |
| PUT | `/api/prompts/:id` | Owner | Edit a prompt |
| DELETE | `/api/prompts/:id` | Owner | Delete a prompt |
| GET | `/api/health` | Public | API health check |

## Project structure

```text
PromptVault/
  client/
    src/
      components/
      context/
      pages/
      services/
      App.jsx
      main.jsx
      styles.css
  server/
    src/
      middleware/
      models/
      routes/
      controllers/
      config/
      server.js
  docs/
    API.md
    TESTING.md
```

## Important team notes
- This is a working starter implementation. Connect it to the team's agreed MongoDB database.
- Do not commit `.env` files or real credentials.
- Review the code with your teammates before merging it into the shared `main` branch.
- Run the tests and verify the API against your team's environment before submitting.
