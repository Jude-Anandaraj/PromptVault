# PromptVault API

Base URL: `http://localhost:5000/api`

Authentication uses a JWT bearer token. Send it as `Authorization: Bearer <token>`.

## Register
`POST /auth/register`
```json
{ "name": "Alex", "email": "alex@example.com", "password": "password123" }
```

## Login
`POST /auth/login`
```json
{ "email": "alex@example.com", "password": "password123" }
```

## List prompts
`GET /prompts?q=writing&category=Writing`

## List categories
`GET /categories` returns supported starter categories and categories already used by prompts.

## Create prompt (authenticated)
`POST /prompts`
```json
{ "title": "Email helper", "description": "Draft a clear email", "content": "Write an email about [topic].", "category": "Writing", "tags": ["email"] }
```

## Update and delete
`PUT /prompts/:id` and `DELETE /prompts/:id`. Only the prompt owner can change or delete it.
