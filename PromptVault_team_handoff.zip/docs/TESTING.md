# Manual test checklist

- [ ] `GET /api/health` returns `{ "status": "ok" }`.
- [ ] Register a new user.
- [ ] Try registering the same email again; expect a conflict message.
- [ ] Log in with the correct password.
- [ ] Try an incorrect password; expect a clear error.
- [ ] Create a prompt while logged in.
- [ ] Browse prompts without logging in.
- [ ] Search by a word in a prompt title or description.
- [ ] Filter prompts by category.
- [ ] Open prompt details and copy prompt text.
- [ ] Edit a prompt as its owner.
- [ ] Try editing another user's prompt; expect HTTP 403.
- [ ] Delete a prompt as its owner.
- [ ] Test the layout at desktop and mobile widths.
- [ ] Confirm `.env` is not committed.
