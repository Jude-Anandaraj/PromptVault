# PromptVault wireframes (A1 draft)

These first-release wireframes map the current API and client scope. They are desktop/mobile layout sketches for team review, not screenshots of the running app.

## Browse to manage journey

1. A visitor browses and filters the public Explore page, then opens a prompt detail page.
2. Choosing **Create prompt** while signed out leads to registration or login.
3. A signed-in member creates a prompt, sees its detail page, and can edit or delete it when they own it.

## Screen scope

- **Explore:** public search, category filters, result cards, loading/error/empty feedback.
- **Prompt details:** public content and copy action; edit/delete controls appear for the owner.
- **Register and login:** public forms with validation and server feedback.
- **Create/edit:** member-only reusable prompt form; category values come from `/api/categories`.
- **Profile:** omitted from the first release because there is no profile route or user profile data in the current API.

## Current contract gaps for team review

The current Prompt model contains title, description, content, category, tags and author. It has no AI platform field. Add that field only after the team confirms the shared API contract. The supplied team guide also asks for current member photos and confirmed team details for the two-slide deck; those assets were not included in the project files.

See [wireframes.svg](wireframes.svg) for desktop and mobile layout sketches.
