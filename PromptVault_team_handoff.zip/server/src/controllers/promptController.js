import Prompt from '../models/Prompt.js';

const fields = ['title', 'description', 'content', 'category', 'tags'];
function cleanPayload(body) {
  const data = {};
  for (const key of fields) if (body[key] !== undefined) data[key] = body[key];
  if (data.tags && !Array.isArray(data.tags)) data.tags = String(data.tags).split(',').map(x => x.trim()).filter(Boolean);
  return data;
}
function validate(data, partial = false) {
  const required = ['title', 'description', 'content', 'category'];
  if (!partial && required.some(k => !String(data[k] || '').trim())) return 'Title, description, content, and category are required.';
  if (data.title && String(data.title).length > 100) return 'Title must be 100 characters or less.';
  if (data.description && String(data.description).length > 500) return 'Description must be 500 characters or less.';
  if (data.content && String(data.content).length > 12000) return 'Prompt content is too long.';
  return null;
}

export async function listPrompts(req, res, next) {
  try {
    const filter = {};
    if (req.query.category && req.query.category !== 'All') filter.category = req.query.category;
    if (req.query.q) filter.$text = { $search: String(req.query.q).slice(0, 100) };
    const prompts = await Prompt.find(filter).populate('author', 'name').sort({ createdAt: -1 }).limit(100);
    res.json({ prompts });
  } catch (error) { next(error); }
}
export async function getPrompt(req, res, next) {
  try {
    const prompt = await Prompt.findById(req.params.id).populate('author', 'name');
    if (!prompt) return res.status(404).json({ message: 'Prompt not found.' });
    res.json({ prompt });
  } catch (error) { next(error); }
}
export async function createPrompt(req, res, next) {
  try {
    const data = cleanPayload(req.body);
    const issue = validate(data);
    if (issue) return res.status(400).json({ message: issue });
    const prompt = await Prompt.create({ ...data, author: req.user._id });
    await prompt.populate('author', 'name');
    res.status(201).json({ prompt });
  } catch (error) { next(error); }
}
export async function updatePrompt(req, res, next) {
  try {
    const prompt = await Prompt.findById(req.params.id);
    if (!prompt) return res.status(404).json({ message: 'Prompt not found.' });
    if (!prompt.author.equals(req.user._id)) return res.status(403).json({ message: 'You can only edit your own prompts.' });
    const data = cleanPayload(req.body);
    const issue = validate(data, true);
    if (issue) return res.status(400).json({ message: issue });
    Object.assign(prompt, data);
    await prompt.save();
    await prompt.populate('author', 'name');
    res.json({ prompt });
  } catch (error) { next(error); }
}
export async function deletePrompt(req, res, next) {
  try {
    const prompt = await Prompt.findById(req.params.id);
    if (!prompt) return res.status(404).json({ message: 'Prompt not found.' });
    if (!prompt.author.equals(req.user._id)) return res.status(403).json({ message: 'You can only delete your own prompts.' });
    await prompt.deleteOne();
    res.json({ message: 'Prompt deleted.' });
  } catch (error) { next(error); }
}
