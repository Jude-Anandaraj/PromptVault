import mongoose from 'mongoose';

const promptSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true, maxlength: 100 },
  description: { type: String, required: true, trim: true, maxlength: 500 },
  content: { type: String, required: true, trim: true, maxlength: 12000 },
  category: { type: String, required: true, trim: true, maxlength: 40 },
  tags: [{ type: String, trim: true, maxlength: 24 }],
  author: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }
}, { timestamps: true });

promptSchema.index({ title: 'text', description: 'text', content: 'text', tags: 'text' });
export default mongoose.model('Prompt', promptSchema);
