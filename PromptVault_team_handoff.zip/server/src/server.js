import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { connectDB } from './config/db.js';
import Prompt from './models/Prompt.js';
import authRoutes from './routes/authRoutes.js';
import promptRoutes from './routes/promptRoutes.js';

const app = express();
app.use(helmet());
app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173' }));
app.use(express.json({ limit: '1mb' }));
app.use('/api', rateLimit({ windowMs: 15 * 60 * 1000, limit: 300 }));
app.get('/api/health', (_req, res) => res.json({ status: 'ok', service: 'PromptVault API' }));
app.use('/api/auth', authRoutes);
app.get('/api/categories', async (_req, res, next) => {
  try {
    const categories = await Prompt.distinct('category');
    res.json({ categories: [...new Set(['Writing', 'Coding', 'Business', 'Education', 'Marketing', 'Productivity', 'Other', ...categories])].sort((a, b) => a.localeCompare(b)) });
  }
  catch (error) { next(error); }
});
app.use('/api/prompts', promptRoutes);
app.use((req, res) => res.status(404).json({ message: 'Route not found.' }));
app.use((error, _req, res, _next) => {
  console.error(error);
  if (error.code === 11000) return res.status(409).json({ message: 'That value is already in use.' });
  if (error.name === 'CastError') return res.status(400).json({ message: 'Invalid resource ID.' });
  res.status(500).json({ message: 'Something went wrong. Please try again.' });
});

const port = process.env.PORT || 5000;
connectDB().then(() => app.listen(port, () => console.log(`PromptVault API running on ${port}`)))
  .catch(error => { console.error('Could not start server:', error.message); process.exit(1); });
